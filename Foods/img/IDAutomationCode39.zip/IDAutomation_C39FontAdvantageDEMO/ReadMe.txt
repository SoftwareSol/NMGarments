IDAutomation's Free Code 39 Barcode Font has been discontinued. 

Included in this zip file is IDAutomation's Demo version of the Code 39 Barcode Font Package, available for purchase at: https://www.idautomation.com/barcode-fonts/code-39/ 